
		<footer class="footer-distributed">

<div class="footer-right">

  <a href="#"><i class="fa fa-facebook"></i></a>
  <a href="#"><i class="fa fa-twitter"></i></a>
  <a href="#"><i class="fa fa-linkedin"></i></a>
  <a href="#"><i class="fa fa-github"></i></a>

</div>

<div class="footer-left">

  <p class="footer-links">
    <a class="link-1" href="#">Home</a>

    <a href="#">About</a>

    <a href="#">Programs</a>

    <a href="#">Events</a>

    <a href="#">Blogs</a>

  </p>

  <p>Our University &copy; 2020</p>
</div>

</footer>
<?php wp_footer();?>
</body>
</html>